# Multi-Agent Code Review & Refactoring System

## Run in VS Code on Windows

1. Open this folder in VS Code.
2. Open Terminal > New Terminal.
3. Create a virtual environment: `py -m venv .venv`
4. Activate: `.\.venv\Scripts\Activate.ps1`
5. Install dependencies: `python -m pip install --upgrade pip`
6. Then: `pip install -r requirements.txt`
7. Optional AI mode: `$env:OPENAI_API_KEY="your_api_key_here"`
8. Run: `python main.py`
9. Choose option 2 for the sample or option 1 for your own `.py` file.
   Direct invocation also works: `python main.py your_code.py`.

Reports are saved in review_output/. AI is optional; without an API key,
AST/Bandit/Radon static analysis still works. Refactored code is not run
automatically. Detection rates need known benchmark counts; test pass rate
needs actual test results.
